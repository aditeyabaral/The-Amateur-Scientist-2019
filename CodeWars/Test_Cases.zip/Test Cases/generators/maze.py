import random
numList = list(range(-100, 100))
dirString = "LRUD"
print(1000)
for _ in range(1000):
    print(random.choice(numList), random.choice(numList))
    randomString="".join([random.choice(dirString) for i in range(random.randint(1,1000))])
    print(randomString)
