import random
print(1000)
for _ in range(1000):
    n = random.randint(1, 1000)    
    a = [random.randint(0,10) for i in range(n)]
    b = [random.randint(0,10) for i in range(n)]
    print(n)
    print(*a, sep=" ", end="\n")
    print(*b, sep=" ", end="\n")
