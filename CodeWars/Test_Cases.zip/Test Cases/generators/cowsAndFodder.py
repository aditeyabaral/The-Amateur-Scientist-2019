import random
print(1000)
for _ in range(1000):
    n = random.randint(10, 1000)
    fodder = [random.randint(1, 1000) for i in range(n)]
    print(n)
    print(*fodder, sep=" ", end="\n")

